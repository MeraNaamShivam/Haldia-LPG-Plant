# Haldia LPG Bottling Plant – Operations Monitoring Website

Static website (HTML + CSS + JavaScript) for GitHub Pages: daily real-time data entry, interactive graphs (Chart.js) and monthly MIS.

## Folder structure
```
index.html          main page
css/style.css       styling
js/app.js           application logic, calculations, charts
data/data.json      published (shared) plant data – replace this to update the website for everyone
.nojekyll           tells GitHub Pages to serve files as-is
```

## Host on GitHub Pages
1. Sign in to github.com → **New repository** (e.g. `haldia-lpg-monitoring`).
2. **Add file → Upload files** → drag ALL files and folders from this zip (keep the folder structure) → **Commit changes**.
3. Go to **Settings → Pages** → Source: **Deploy from a branch** → Branch: `main`, folder `/ (root)` → **Save**.
4. After 1–2 minutes the site is live at `https://<your-username>.github.io/haldia-lpg-monitoring/`.

## How data works
* Entries made on the website are saved in **that user's browser** (no server on GitHub Pages).
* To share data with all viewers: **Admin → Export / Backup → Download data.json**, then upload it to the `data` folder of the repository (replace) and commit. Everyone sees it within 1–2 minutes.
* Take weekly backups from **Admin → Export / Backup**.

## Pages
* Live Dashboard, Daily Analytics (charts), Monthly Trends (charts)
* Daily entry: plant start time, manpower, morning equipment report, hourly production / SQC / trucks / lorries (06:00–22:00), production loss (tagged), consumables, valve & cap salvaging, DPT / HR / PT / cold repair, sales-area lorry invoices (Kolkata, Balasore), electricity, cylinder stock
* Weekly maintenance report
* Monthly: PT cylinders vs paint, Revex head-wise, Capex, Production vs Cost (Rs/MT), MIS report, custom monthly reports
* Settings: equipment, work points, loss tags, consumables, sales areas, cost heads, targets

## Important
A GitHub Pages site is **publicly accessible on the internet**. Do not publish confidential company data (cost, Revex/Capex, invoice details) without approval from the IS / IT department. If needed, use a private repository with GitHub Enterprise or host the same files on an internal server.


/* =========================================================
   CONFIG & CONSTANTS
   ========================================================= */
const CYL=[{k:'c142',n:'14.2 Kg',kg:14.2},{k:'c19',n:'19 Kg',kg:19},{k:'c5',n:'5 Kg',kg:5},{k:'c475',n:'47.5 Kg',kg:47.5}];
const HOURS=[];for(let h=6;h<22;h++)HOURS.push(String(h).padStart(2,'0')+':00-'+String(h+1).padStart(2,'0')+':00');
const DEF_SETTINGS={
  plantName:'Haldia LPG Bottling Plant',
  equipment:['Carousel-1','Carousel-2','Chain Conveyor System','LPG Compressor-1','LPG Compressor-2','LPG Pump-1','LPG Pump-2','Evacuation Unit (LPG Compressor LB081)','Air Compressor-1','Air Compressor-2','Air Dryer','Check Scale-1','Check Scale-2','Weight Correction Unit','VLD (Valve Leak Detector)','OLD (O-Ring Leak Detector)','Test Bath','HASM (Sealing Machine)','Cylinder Washing Unit-1','Cylinder Washing Unit-2','Cylinder Washing Unit-3','Centralised Soap Solution System','DPT Shed Equipment','Fire Water Pump-1','Fire Water Pump-2','Jockey Pump','DG Set','Transformer / HT Panel','ETP (10 KLD)','CCTV / VAMS / Boom Barrier'],
  manpower:['Shed Labour (Contract)','Carousel Operator','Weight Correction Unit','VCM / Valve Changing','Evacuation Unit Operator','Test Bath','SQC Staff','Manual Filling','Loading / Unloading Labour','DPT Shed','PT / Painting Shed','Mechanical Maintenance','Electrical Maintenance','Housekeeping','Security / CISF','Officers / Staff'],
  lossTags:['Mechanical Breakdown','Electrical Breakdown','Carousel Breakdown','Chain Conveyor Jam / Chain Cut','Compressor / Pump Trip','Power Failure','Bulk LPG / Gas Shortage','Empty Cylinder Shortage','Lorry Not Available','Manpower Shortage','Late Start of Shift','Air Pressure Low','Rain / Weather','IR Issue','Planned Shutdown / Maintenance','Others'],
  consumables:['SC Valves','O-Rings','PVC Seals','Delrin Caps','Red Paint (Ltr)','Primer (Ltr)','Soap (Ltr)','Seal Stickers','Grease (Kg)','Cotton Waste (Kg)'],
  salesAreas:['Kolkata','Balasore'],
  revexHeads:['Own Use-FG Others','Utilities (Power & Water)','Fire Fighting Exp','Safety Exps','CISF / Security Exps','Stores & Consumables','Repairs & Maintenance','Salaries & Wages','Contract Services - Casual Labour','Meetings & Events','Charges - 3rd Party (Op Exp)','Others'],
  t:{costPerMT:1300,kwhPerMT:8.5,scValvePct:0.9,delrinPct:10,fillAcc:99,dailyMT:250,dptInv:1200,hrInv:800,lorryCap:342}
};

/* =========================================================
   STORAGE (localStorage + optional LAN server sync)
   ========================================================= */
const LS='hlpg_store_v1';
let STORE=JSON.parse(localStorage.getItem(LS)||'{}');
let SERVER=false,lastTs=0,lastRender=Date.now();
function persist(){localStorage.setItem(LS,JSON.stringify(STORE))}
function get(k,d){return STORE[k]===undefined?clone(d):STORE[k]}
function set(k,v){STORE[k]=v;persist();lastRender=Date.now();
  }
function clone(o){return o===undefined?o:JSON.parse(JSON.stringify(o))}
function S(){const s=get('settings',{});const d=clone(DEF_SETTINGS);return Object.assign(d,s,{t:Object.assign(d.t,s.t||{})})}
/* Published data: data/data.json in the GitHub repo (read-only shared baseline).
   Local entries in this browser override published values for the same key. */
let PUB={};
async function loadPublished(){
  try{const r=await fetch('data/data.json?v='+Date.now(),{cache:'no-store'});if(!r.ok)throw 0;PUB=await r.json();
    const n=Object.keys(PUB).length;
    $('#mode').textContent=n?'● Published data loaded':'Local mode';if(n)$('#mode').classList.add('live');
    for(const k in PUB)if(!(k in STORE))STORE[k]=PUB[k];
    render();
  }catch(e){$('#mode').textContent='Local mode'}
}
/* =========================================================
   HELPERS
   ========================================================= */
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const N=v=>{const x=parseFloat(v);return isNaN(x)?0:x};
const fmt=(v,d=0)=>(isFinite(v)?Number(v):0).toLocaleString('en-IN',{minimumFractionDigits:d,maximumFractionDigits:d});
const todayStr=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const dk=(date,sec)=>'d:'+date+':'+sec;
const mk=(m,sec)=>'m:'+m+':'+sec;
function getPath(o,p){return p.split('.').reduce((a,x)=>a==null?undefined:a[x],o)}
function setPath(o,p,v){const ps=p.split('.');let c=o;ps.slice(0,-1).forEach(x=>{if(typeof c[x]!=='object'||c[x]===null)c[x]={};c=c[x]});c[ps[ps.length-1]]=v;return o}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('on'),1800)}
function mins(a,b){if(!a||!b)return 0;const[h1,m1]=a.split(':').map(Number),[h2,m2]=b.split(':').map(Number);let d=(h2*60+m2)-(h1*60+m1);if(d<0)d+=1440;return d}
function daysOfMonth(m){const[y,mo]=m.split('-').map(Number);const n=new Date(y,mo,0).getDate();return Array.from({length:n},(_,i)=>m+'-'+String(i+1).padStart(2,'0'))}
function weekStart(date){const d=new Date(date+'T00:00:00');const w=(d.getDay()+6)%7;d.setDate(d.getDate()-w);return d.toISOString().slice(0,10)}
function prevMonths(m,n){const[y,mo]=m.split('-').map(Number);const r=[];for(let i=n-1;i>=0;i--){const d=new Date(y,mo-1-i,1);r.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'))}return r}
function monthName(m){const[y,mo]=m.split('-').map(Number);return new Date(y,mo-1,1).toLocaleString('en-IN',{month:'short',year:'numeric'})}
/* bound input: data-k (store key) data-p (path) */
function I(k,p,type='number',extra=''){const v=getPath(get(k,{}),p);return `<input type="${type}" data-k="${esc(k)}" data-p="${esc(p)}" value="${esc(v??'')}" ${type==='number'?'step="any" min="0"':''} ${extra}>`}
function SEL(k,p,opts,extra=''){const v=getPath(get(k,{}),p)??'';return `<select data-k="${esc(k)}" data-p="${esc(p)}" ${extra}><option value=""></option>${opts.map(o=>`<option ${o===v?'selected':''}>${esc(o)}</option>`).join('')}</select>`}
document.addEventListener('change',e=>{const el=e.target;if(!el.dataset.k)return;
  const k=el.dataset.k,p=el.dataset.p;const o=clone(get(k,{}))||{};
  setPath(o,p,el.type==='number'?(el.value===''?'':N(el.value)):el.value);if(k.endsWith(':cons'))for(const c in o)o[c].issued=N(o[c].iA)+N(o[c].iB);set(k,o);
  if(el.dataset.rr!=='0')softRender();toast('Saved ✓');});
/* list-type sections (arrays) */
function listAdd(k,row){const a=get(k,[]);a.push(row);set(k,a);render()}
function listDel(k,i){if(!confirm('Delete this row?'))return;const a=get(k,[]);a.splice(i,1);set(k,a);render()}
function listSet(k,i,f,el){const a=get(k,[]);a[i][f]=el.type==='number'?N(el.value):el.value;set(k,a);softRender();toast('Saved ✓')}
function LI(k,i,f,v,type='text',extra=''){return `<input type="${type}" value="${esc(v??'')}" ${type==='number'?'step="any" min="0"':''} onchange="listSet('${k}',${i},'${f}',this)" ${extra}>`}
function LS_(k,i,f,v,opts){return `<select onchange="listSet('${k}',${i},'${f}',this)"><option></option>${opts.map(o=>`<option ${o===v?'selected':''}>${esc(o)}</option>`).join('')}</select>`}
let srT;function softRender(){clearTimeout(srT);srT=setTimeout(()=>{const y=window.scrollY;const a=document.activeElement;const id=a&&a.dataset?a.dataset.k+'|'+a.dataset.p:null;render();window.scrollTo(0,y);if(id){const n=document.querySelector(`[data-k="${CSS.escape(a.dataset.k||'')}"][data-p="${CSS.escape(a.dataset.p||'')}"]`);n&&n.focus()}},250)}

/* =========================================================
   CALCULATIONS
   ========================================================= */
function daySum(date){
  const s=S(),h=get(dk(date,'hourly'),{}),r={date,cyl:{},nos:0,mt:0,sqcChk:0,sqcOk:0,under:0,over:0,leak:0,trucks:0,lorries:0,hours:0};
  CYL.forEach(c=>r.cyl[c.k]=0);
  HOURS.forEach(hr=>{const x=h[hr]||{};let any=false;CYL.forEach(c=>{r.cyl[c.k]+=N(x[c.k]);if(N(x[c.k]))any=true});if(any)r.hours++;
    r.sqcChk+=N(x.sqcChk);r.sqcOk+=N(x.sqcOk);r.under+=N(x.under);r.over+=N(x.over);r.leak+=N(x.leak);r.trucks+=N(x.trucks);r.lorries+=N(x.lorries)});
  CYL.forEach(c=>{r.nos+=r.cyl[c.k];r.mt+=r.cyl[c.k]*c.kg/1000});
  r.acc=r.sqcChk?r.sqcOk/r.sqcChk*100:null;
  const loss=get(dk(date,'loss'),[]);r.lossMin=0;r.lossCyl=0;r.lossByTag={};
  loss.forEach(l=>{const m=mins(l.from,l.to);r.lossMin+=m;r.lossCyl+=N(l.cyl);r.lossByTag[l.tag||'Untagged']=(r.lossByTag[l.tag||'Untagged']||0)+m});
  const d=get(dk(date,'dpt'),{});r.dpt=N(d.dpt);r.hr=N(d.hr);r.ptRecv=N(d.ptRecv);r.ptSent=N(d.ptSent);r.cold=N(d.cold);r.evac=N(d.evac);r.bodyLeak=N(d.bodyLeak);r.bungLeak=N(d.bungLeak);
  const sv=get(dk(date,'salvage'),{});r.valveSalv=N(sv.valveSalv);r.valveScrap=N(sv.valveScrap);r.capSalv=N(sv.capSalv);r.capScrap=N(sv.capScrap);r.valveRecv=N(sv.valveRecv);r.capRecv=N(sv.capRecv);
  const e=get(dk(date,'elec'),{});r.kwh=e.close!==undefined&&e.close!==''&&e.open!==''?Math.max(0,(N(e.close)-N(e.open))*(N(e.mf)||1)):0;r.dgKwh=N(e.dg);r.kwhMT=r.mt?(r.kwh+r.dgKwh)/r.mt:null;
  const cons=get(dk(date,'cons'),{});r.cons=cons;
  const inv=get(dk(date,'invoice'),[]);r.inv={};s.salesAreas.forEach(a=>r.inv[a]={lorries:0,nos:0,mt:0});
  inv.forEach(i=>{const a=i.area||'Unassigned';r.inv[a]=r.inv[a]||{lorries:0,nos:0,mt:0};r.inv[a].lorries++;CYL.forEach(c=>{r.inv[a].nos+=N(i[c.k]);r.inv[a].mt+=N(i[c.k])*c.kg/1000})});
  r.invCount=inv.length;
  const mp=get(dk(date,'manpower'),{});r.mpA=0;r.mpB=0;s.manpower.forEach(m=>{r.mpA+=N((mp[m]||{}).A);r.mpB+=N((mp[m]||{}).B)});
  const eq=get(dk(date,'equip'),{});r.eqW=0;r.eqNW=0;r.eqM=0;s.equipment.forEach(q=>{const st=(eq[q]||{}).st;if(st==='Working')r.eqW++;else if(st==='Not Working')r.eqNW++;else if(st==='Under Maintenance')r.eqM++});
  r.start=get(dk(date,'start'),{});
  r.stock=get(dk(date,'stock'),{});
  return r;
}
function consSum(days,item,f='consumed'){return days.reduce((a,d)=>a+N((get(dk(d,'cons'),{})[item]||{})[f]),0)}
function monthSum(m){
  const days=daysOfMonth(m),ds=days.map(daySum),s=S();
  const r={m,days:ds,work:ds.filter(d=>d.nos>0).length,cyl:{},nos:0,mt:0,sqcChk:0,sqcOk:0,trucks:0,lorries:0,lossMin:0,lossCyl:0,lossByTag:{},dpt:0,hr:0,ptRecv:0,ptSent:0,cold:0,kwh:0,dgKwh:0,valveSalv:0,capSalv:0,valveScrap:0,capScrap:0,inv:{},invCount:0,evac:0};
  CYL.forEach(c=>r.cyl[c.k]=0);
  ds.forEach(d=>{CYL.forEach(c=>r.cyl[c.k]+=d.cyl[c.k]);['nos','mt','sqcChk','sqcOk','trucks','lorries','lossMin','lossCyl','dpt','hr','ptRecv','ptSent','cold','kwh','dgKwh','valveSalv','capSalv','valveScrap','capScrap','invCount','evac'].forEach(k=>r[k]+=d[k]);
    for(const t in d.lossByTag)r.lossByTag[t]=(r.lossByTag[t]||0)+d.lossByTag[t];
    for(const a in d.inv){r.inv[a]=r.inv[a]||{lorries:0,nos:0,mt:0};r.inv[a].lorries+=d.inv[a].lorries;r.inv[a].nos+=d.inv[a].nos;r.inv[a].mt+=d.inv[a].mt}});
  const ov=get(mk(m,'prodOverride'),{});if(N(ov.mt))r.mt=N(ov.mt);
  r.acc=r.sqcChk?r.sqcOk/r.sqcChk*100:null;r.kwhMT=r.mt?(r.kwh+r.dgKwh)/r.mt:null;
  r.cons={};s.consumables.forEach(c=>r.cons[c]={issued:consSum(days,c,'issued'),consumed:consSum(days,c,'consumed')});
  const rv=get(mk(m,'revex'),{});r.revex=0;r.revexBud=0;s.revexHeads.forEach(h=>{r.revex+=N((rv[h]||{}).act);r.revexBud+=N((rv[h]||{}).bud)});
  r.rsMT=r.mt?r.revex/(r.mt):null; // revex in Rs; Rs/MT
  const cp=get(mk(m,'capex'),[]);r.capex=cp.reduce((a,x)=>a+N(x.month),0);
  return r;
}

/* =========================================================
   SVG CHARTS (no internet needed)
   ========================================================= */
const COLORS=['#0b3c8c','#f0b400','#1a9e55','#d93636','#7b4bc4','#14a3b8','#e46f1f','#5b6475'];
function svgChart(labels,series,o={}){
  const W=760,H=o.h||260,pl=48,pr=o.right?48:14,pt=14,pb=o.rot?62:34,iw=W-pl-pr,ih=H-pt-pb;
  const bars=series.filter(s=>s.type!=='line'&&!s.right),lines=series.filter(s=>s.type==='line'&&!s.right),rs=series.filter(s=>s.right);
  let mx=0;if(o.stack){labels.forEach((_,i)=>{mx=Math.max(mx,bars.reduce((a,s)=>a+N(s.data[i]),0))})}else bars.forEach(s=>s.data.forEach(v=>mx=Math.max(mx,N(v))));
  lines.forEach(s=>s.data.forEach(v=>mx=Math.max(mx,N(v))));if(o.target)mx=Math.max(mx,o.target);mx=mx||1;mx=nice(mx);
  let rmx=1;rs.forEach(s=>s.data.forEach(v=>rmx=Math.max(rmx,N(v))));rmx=nice(rmx);
  const X=i=>pl+iw*(i+.5)/labels.length,Y=v=>pt+ih-ih*N(v)/mx,YR=v=>pt+ih-ih*N(v)/rmx;
  let g=`<svg viewBox="0 0 ${W} ${H}" class="chart" style="height:${H}px" preserveAspectRatio="none">`;
  for(let i=0;i<=4;i++){const v=mx*i/4,y=Y(v);g+=`<line x1="${pl}" x2="${W-pr}" y1="${y}" y2="${y}" stroke="#e5e9f2"/><text x="${pl-5}" y="${y+4}" font-size="10" text-anchor="end" fill="#6b7486">${fmt(v,v<10&&mx<10?1:0)}</text>`;
    if(rs.length)g+=`<text x="${W-pr+5}" y="${y+4}" font-size="10" fill="#6b7486">${fmt(rmx*i/4,rmx<10?1:0)}</text>`}
  const bw=iw/labels.length*.75;
  if(o.stack){labels.forEach((_,i)=>{let acc=0;bars.forEach((s,si)=>{const v=N(s.data[i]);if(!v)return;const y1=Y(acc+v),y0=Y(acc);g+=`<rect x="${X(i)-bw/2}" y="${y1}" width="${bw}" height="${y0-y1}" fill="${s.color||COLORS[si]}"><title>${esc(labels[i])} – ${esc(s.name)}: ${fmt(v,1)}</title></rect>`;acc+=v})})}
  else{const bwi=bw/Math.max(1,bars.length);bars.forEach((s,si)=>s.data.forEach((v,i)=>{const x=X(i)-bw/2+si*bwi;g+=`<rect x="${x}" y="${Y(v)}" width="${bwi-1}" height="${pt+ih-Y(v)}" fill="${s.color||COLORS[si]}" rx="1.5"><title>${esc(labels[i])} – ${esc(s.name)}: ${fmt(v,2)}</title></rect>`;if(o.vals&&N(v))g+=`<text x="${x+bwi/2}" y="${Y(v)-3}" font-size="9.5" text-anchor="middle" fill="#333">${fmt(v,o.vd||0)}</text>`}))}
  [...lines.map(s=>[s,Y]),...rs.map(s=>[s,YR])].forEach(([s,f],si)=>{const pts=s.data.map((v,i)=>v===null||v===''||v===undefined?null:[X(i),f(v)]);let d='';pts.forEach((p,i)=>{if(p)d+=(d&&pts[i-1]?'L':'M')+p[0]+','+p[1]});
    g+=`<path d="${d}" fill="none" stroke="${s.color}" stroke-width="2.2"/>`;pts.forEach((p,i)=>{if(p)g+=`<circle cx="${p[0]}" cy="${p[1]}" r="3" fill="${s.color}"><title>${esc(labels[i])} – ${esc(s.name)}: ${fmt(s.data[i],2)}</title></circle>`})});
  if(o.target){const y=Y(o.target);g+=`<line x1="${pl}" x2="${W-pr}" y1="${y}" y2="${y}" stroke="#d93636" stroke-dasharray="5 4"/><text x="${W-pr-2}" y="${y-4}" font-size="10" text-anchor="end" fill="#d93636">Target ${fmt(o.target,1)}</text>`}
  labels.forEach((l,i)=>{if(labels.length>20&&i%2)return;g+=o.rot?`<text transform="translate(${X(i)},${H-pb+12}) rotate(-40)" font-size="10" text-anchor="end" fill="#555">${esc(l)}</text>`:`<text x="${X(i)}" y="${H-pb+15}" font-size="10" text-anchor="middle" fill="#555">${esc(l)}</text>`});
  g+=`<line x1="${pl}" x2="${W-pr}" y1="${pt+ih}" y2="${pt+ih}" stroke="#999"/></svg>`;
  g+=`<div class="legend">${series.map((s,i)=>`<span><i style="background:${s.color||COLORS[i]}"></i>${esc(s.name)}${s.right?' (right axis)':''}</span>`).join('')}</div>`;
  return g;
}

/* ---------- Chart.js rendering (falls back to SVG if CDN not reachable) ---------- */
let CHQ=[],CHI=[];
function chart(labels,series,o={}){
  if(!window.Chart)return svgChart(labels,series,o);
  const id='ch'+CHQ.length+'_'+Date.now();CHQ.push({id,kind:'xy',labels,series,o});
  return `<div class="chart-box" style="height:${o.h||270}px"><canvas id="${id}"></canvas></div>`;
}
function pie(labels,data,o={}){
  if(!window.Chart)return svgChart(labels,[{name:o.name||'Value',data,color:'#0b3c8c'}],{rot:true,vals:true});
  const id='ch'+CHQ.length+'_'+Date.now();CHQ.push({id,kind:o.doughnut===false?'pie':'doughnut',labels,data,o});
  return `<div class="chart-box" style="height:${o.h||260}px"><canvas id="${id}"></canvas></div>`;
}
const valPlugin={id:'vals',afterDatasetsDraw(c){if(!c.options.plugins.vals)return;const x=c.ctx;x.save();x.font='10px Segoe UI';x.fillStyle='#333';x.textAlign='center';
  c.data.datasets.forEach((d,i)=>{if(d.type==='line'||c.getDatasetMeta(i).hidden)return;c.getDatasetMeta(i).data.forEach((b,j)=>{const v=d.data[j];if(v)x.fillText(fmt(v,c.options.plugins.vd||0),b.x,b.y-4)})});x.restore()}};
function drawCharts(){
  CHI.forEach(c=>c.destroy());CHI=[];
  CHQ.forEach(q=>{const el=document.getElementById(q.id);if(!el)return;let cfg;
    if(q.kind==='xy'){const o=q.o;
      const ds=q.series.map((s,i)=>({label:s.name+(s.right?' (R)':''),data:s.data.map(v=>v===null||v===''?null:N(v)),type:s.type==='line'?'line':'bar',
        backgroundColor:s.color||COLORS[i],borderColor:s.color||COLORS[i],borderWidth:s.type==='line'?2.5:0,tension:.3,pointRadius:3,spanGaps:true,
        yAxisID:s.right?'y1':'y',stack:o.stack&&s.type!=='line'?'st':undefined,order:s.type==='line'?0:1,borderRadius:3}));
      if(o.target)ds.push({label:'Target '+o.target,data:q.labels.map(()=>o.target),type:'line',borderColor:'#d93636',borderDash:[6,4],borderWidth:1.5,pointRadius:0,yAxisID:'y',order:0});
      cfg={type:'bar',data:{labels:q.labels,datasets:ds},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},
        plugins:{legend:{position:'bottom',labels:{boxWidth:12,font:{size:11}}},vals:!!o.vals,vd:o.vd,tooltip:{callbacks:{label:c=>c.dataset.label+': '+fmt(c.raw,2)}}},
        scales:{x:{stacked:!!o.stack,ticks:{maxRotation:o.rot?45:0,autoSkip:true,font:{size:10}},grid:{display:false}},y:{stacked:!!o.stack,beginAtZero:!o.yMin,min:o.yMin,ticks:{font:{size:10}}},
        ...(q.series.some(s=>s.right)?{y1:{position:'right',beginAtZero:true,grid:{drawOnChartArea:false},ticks:{font:{size:10}}}}:{})}},plugins:[valPlugin]};
      if(o.horizontal){cfg.options.indexAxis='y'}
    }else{
      cfg={type:q.kind,data:{labels:q.labels,datasets:[{data:q.data,backgroundColor:q.labels.map((_,i)=>(q.o.colors||COLORS)[i%COLORS.length]),borderWidth:1}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{boxWidth:12,font:{size:11}}},
        tooltip:{callbacks:{label:c=>{const t=c.dataset.data.reduce((a,b)=>a+N(b),0);return c.label+': '+fmt(c.raw,2)+' ('+(t?fmt(c.raw/t*100,1):0)+'%)'}}}}}};
    }
    CHI.push(new Chart(el,cfg));});
  CHQ=[];
}
function nice(v){const p=Math.pow(10,Math.floor(Math.log10(v)));const f=v/p;return(f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10)*p}

/* =========================================================
   NAVIGATION
   ========================================================= */
const PAGES=[
 ['Live','dash','📊 Live Dashboard'],['Live','analytics','📉 Daily Analytics (Charts)'],['Live','trends','📈 Monthly Trends (Charts)'],
 ['Daily Entry','start','⏱ Plant Start Time'],['Daily Entry','manpower','👷 Manpower (Work-wise)'],['Daily Entry','equip','⚙ Morning Equipment Report'],
 ['Daily Entry','hourly','🕑 Hourly Production / SQC / Trucks'],['Daily Entry','loss','⛔ Production Loss (Tagged)'],['Daily Entry','cons','📦 Consumables Issued'],
 ['Daily Entry','salvage','🔧 Valve & Cap Salvaging'],['Daily Entry','dpt','🛢 DPT / HR / PT / Cold Repair'],['Daily Entry','invoice','🚚 Lorry Invoice (Sales Area)'],
 ['Daily Entry','elec','⚡ Electricity Consumption'],['Daily Entry','stock','🏭 Cylinder Stock'],
 ['Daily Report','daily','🗒 Daily Report (Print)'],
 ['Weekly','weekly','🛠 Weekly Maintenance'],
 ['Monthly','ptpaint','🎨 PT Cylinders vs Paint'],['Monthly','revex','💰 Revex – Head-wise'],['Monthly','capex','🏗 Capex Consumption'],['Monthly','cost','📈 Production vs Cost (Rs/MT)'],
 ['Monthly','mis','📑 Monthly MIS Report'],['Monthly','custom','🧩 Other Monthly Reports'],
 ['Admin','export','⬇ Export / Backup'],['Admin','settings','⚙ Settings & Masters']];
let PAGE=location.hash.slice(1)||'dash';
function buildNav(){let g='',h='';PAGES.forEach(([grp,id,t])=>{if(grp!==g){h+=`<div class="grp">${grp}</div>`;g=grp}h+=`<a class="${PAGE===id?'act':''}" onclick="go('${id}')">${t}</a>`});$('#nav').innerHTML=h}
function go(p){PAGE=p;location.hash=p;render();window.scrollTo(0,0)}
const D=()=>$('#gDate').value||todayStr();const M=()=>$('#gMonth').value||todayStr().slice(0,7);
function render(){buildNav();CHQ=[];const f=VIEWS[PAGE]||VIEWS.dash;$('#main').innerHTML=f();drawCharts();$('#nav').classList.remove('open')}

/* =========================================================
   VIEWS
   ========================================================= */
const VIEWS={};
const head=(t,d)=>`<h2>${t}</h2><p class="desc">${d}</p>`;
const dateLbl=()=>new Date(D()+'T00:00').toLocaleDateString('en-IN',{weekday:'long',day:'2-digit',month:'short',year:'numeric'});

VIEWS.dash=()=>{
  const d=D(),r=daySum(d),s=S(),t=s.t,h=get(dk(d,'hourly'),{});
  const nowH=new Date().getHours(),isToday=d===todayStr();
  const curHr=HOURS.find(x=>parseInt(x)===nowH);const cur=curHr?(h[curHr]||{}):{};const curNos=CYL.reduce((a,c)=>a+N(cur[c.k]),0);
  const st=r.start,late=st.introA&&st.stdA&&mins(st.stdA,st.introA)>0&&mins(st.stdA,st.introA)<600;
  const dptInv=N(r.stock.dptInv),hrInv=N(r.stock.hrInv);
  let k=`<div class="kpis">
   ${kpi('Plant Start (Shift A)',st.introA||'—',st.introA?('Cyl. introduction'+(late?` • <span class="bad">Late ${mins(st.stdA,st.introA)} min</span>`:' • <span class="ok">On time</span>')):'Not entered',late?'r':'g')}
   ${kpi('Plant Start (Shift B)',st.introB||'—',st.introB?'Cyl. introduction':'Not entered')}
   ${kpi('Manpower Present',fmt(r.mpA+r.mpB),`A: ${r.mpA} • B: ${r.mpB}`)}
   ${kpi('Equipment Working',`${r.eqW}/${s.equipment.length}`,`<span class="bad">${r.eqNW} not working</span> • ${r.eqM} under maint.`,r.eqNW?'r':'g')}
   ${kpi('Cylinders Filled (Today)',fmt(r.nos),`${fmt(r.mt,2)} MT • ${r.hours} productive hrs`,r.mt>=t.dailyMT?'g':'y')}
   ${kpi(isToday&&curHr?'Current Hour ('+curHr+')':'Avg / Hour',fmt(isToday&&curHr?curNos:(r.hours?r.nos/r.hours:0)),'Cylinders')}
   ${kpi('Filling Accuracy (SQC)',r.acc===null?'—':fmt(r.acc,2)+'%',`${fmt(r.sqcChk)} checked • U:${r.under} O:${r.over} L:${r.leak}`,r.acc===null?'':r.acc>=t.fillAcc?'g':'r')}
   ${kpi('Trucks Reported',fmt(r.trucks),'Hourly total')}
   ${kpi('Lorries Filled',fmt(r.lorries),`Invoiced: ${r.invCount}`)}
   ${s.salesAreas.map(a=>kpi('Invoice – '+a,fmt((r.inv[a]||{}).lorries||0),`${fmt((r.inv[a]||{}).nos||0)} cyl • ${fmt((r.inv[a]||{}).mt||0,2)} MT`)).join('')}
   ${kpi('Production Loss',fmt(r.lossMin)+' min',`${Object.keys(r.lossByTag).length} tags • ${fmt(r.lossCyl)} cyl lost`,r.lossMin?'r':'g')}
   ${kpi('DPT / HR Generated',`${r.dpt} / ${r.hr}`,`PT received: ${r.ptRecv} • Cold repair: ${r.cold}`)}
   ${kpi('Valve / Cap Salvaged',`${r.valveSalv} / ${r.capSalv}`,`Scrap: ${r.valveScrap} / ${r.capScrap}`)}
   ${kpi('Electricity',fmt(r.kwh+r.dgKwh)+' kWh',r.kwhMT===null?'—':`${fmt(r.kwhMT,2)} kWh/MT (Target ${t.kwhPerMT})`,r.kwhMT===null?'':r.kwhMT<=t.kwhPerMT?'g':'r')}
   ${kpi('Filled Stock',fmt(CYL.reduce((a,c)=>a+N((r.stock[c.k]||{}).filled),0)),'Empty: '+fmt(CYL.reduce((a,c)=>a+N((r.stock[c.k]||{}).empty),0)))}
   ${kpi('DPT / HR Inventory',`${dptInv||'—'} / ${hrInv||'—'}`,`Norm ${t.dptInv} / ${t.hrInv}`,(dptInv>t.dptInv||hrInv>t.hrInv)?'r':'g')}
  </div>`;
  const labs=HOURS.map(x=>x.slice(0,5));
  const prod=HOURS.map(x=>CYL.reduce((a,c)=>a+N((h[x]||{})[c.k]),0));let cum=0;const cumMT=HOURS.map(x=>{cum+=CYL.reduce((a,c)=>a+N((h[x]||{})[c.k])*c.kg/1000,0);return +cum.toFixed(2)});
  const acc=HOURS.map(x=>{const y=h[x]||{};return N(y.sqcChk)?+(N(y.sqcOk)/N(y.sqcChk)*100).toFixed(2):null});
  const tagL=Object.keys(r.lossByTag);
  return head('Live Dashboard – '+dateLbl(),'Auto-refreshes as data is entered. '+'Data entered here is saved in this browser. To share with everyone, publish it to GitHub (Admin → Export / Backup → Publish).')+
  (Object.keys(STORE).length<3?`<div class="note">No data yet. Start entering data from the <b>Daily Entry</b> menu, or <a href="#" onclick="demo();return false">load sample data</a> to preview the dashboards.</div>`:'')+k+
  `<div class="grid2"><div class="card"><h3>Hourly Production (Cylinders, type-wise) & Cumulative MT</h3>${chart(labs,[...CYL.map((c,i)=>({name:c.n,data:HOURS.map(x=>N((h[x]||{})[c.k])),color:COLORS[i]})),{name:'Cumulative MT',type:'line',right:true,data:cumMT,color:'#d93636'}],{stack:true,right:true})}</div>
  <div class="card"><h3>Hourly SQC – Filling Accuracy %</h3>${chart(labs,[{name:'Accuracy %',type:'line',data:acc,color:'#1a9e55'}],{target:t.fillAcc})}</div>
  <div class="card"><h3>Hourly Trucks Reported vs Lorries Filled</h3>${chart(labs,[{name:'Trucks Reported',data:HOURS.map(x=>N((h[x]||{}).trucks)),color:'#0b3c8c'},{name:'Lorries Filled',data:HOURS.map(x=>N((h[x]||{}).lorries)),color:'#f0b400'}],{vals:true})}</div>
  <div class="card"><h3>Production Loss by Tag (minutes)</h3>${tagL.length?chart(tagL,[{name:'Loss (min)',data:tagL.map(x=>r.lossByTag[x]),color:'#d93636'}],{vals:true,rot:true}):'<p class="desc">No production loss recorded today. ✅</p>'}</div></div>
  <div class="grid3"><div class="card"><h3>Cylinders Filled – Type-wise</h3>${r.nos?pie(CYL.map(c=>c.n),CYL.map(c=>r.cyl[c.k])):'<p class="desc">No production yet.</p>'}</div>
  <div class="card"><h3>Lorry Invoices – Sales Area</h3>${r.invCount?pie(Object.keys(r.inv),Object.values(r.inv).map(v=>v.lorries),{colors:['#0b3c8c','#f0b400','#1a9e55','#d93636']}):'<p class="desc">No invoices yet.</p>'}</div>
  <div class="card"><h3>Equipment Status</h3>${(r.eqW+r.eqNW+r.eqM)?pie(['Working','Not Working','Under Maintenance'],[r.eqW,r.eqNW,r.eqM],{colors:['#1a9e55','#d93636','#e69500']}):'<p class="desc">Morning report not updated.</p>'}</div></div>`;
};
function kpi(l,v,s,c=''){return `<div class="kpi ${c}"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s||''}</div></div>`}


VIEWS.analytics=()=>{const d=D(),r=daySum(d),s=S(),t=s.t,h=get(dk(d,'hourly'),{}),labs=HOURS.map(x=>x.slice(0,5));
 const mp=get(dk(d,'manpower'),{}),cons=r.cons;
 const tot=HOURS.map(x=>CYL.reduce((a,c)=>a+N((h[x]||{})[c.k]),0));
 const avg=r.hours?r.nos/r.hours:0;
 const conPct=s.consumables.filter(c=>!/Ltr|Kg/.test(c));
 const sv=get(dk(d,'salvage'),{});
 return head('Daily Analytics – '+dateLbl(),'Graphical view of all daily parameters.')+
 `<div class="grid2">
 <div class="card"><h3>Hourly Production – Total Cylinders vs Average</h3>${chart(labs,[{name:'Cylinders',data:tot,color:'#0b3c8c'},{name:'Average/hr',type:'line',data:labs.map(()=>+avg.toFixed(0)),color:'#f0b400'}],{vals:true})}</div>
 <div class="card"><h3>Hourly SQC – Under / Over / Leak</h3>${chart(labs,[{name:'Under-wt',data:HOURS.map(x=>N((h[x]||{}).under)),color:'#e69500'},{name:'Over-wt',data:HOURS.map(x=>N((h[x]||{}).over)),color:'#7b4bc4'},{name:'Leak',data:HOURS.map(x=>N((h[x]||{}).leak)),color:'#d93636'}],{stack:true})}</div>
 <div class="card"><h3>Manpower – Work-wise (Shift A vs B)</h3>${chart(s.manpower,[{name:'Shift A',data:s.manpower.map(m=>N((mp[m]||{}).A)),color:'#0b3c8c'},{name:'Shift B',data:s.manpower.map(m=>N((mp[m]||{}).B)),color:'#14a3b8'},{name:'Required',type:'line',data:s.manpower.map(m=>N((mp[m]||{}).req)||null),color:'#d93636'}],{rot:true,h:320})}</div>
 <div class="card"><h3>Consumables – Issued vs Consumed</h3>${chart(conPct,[{name:'Issued',data:conPct.map(c=>N((cons[c]||{}).iA)+N((cons[c]||{}).iB)),color:'#9db4e0'},{name:'Consumed',data:conPct.map(c=>N((cons[c]||{}).consumed)),color:'#0b3c8c'}],{rot:true,h:320})}</div>
 <div class="card"><h3>Valve & Cap Salvaging</h3>${chart(['SC Valves','Delrin Caps'],[{name:'Received',data:[N(sv.valveRecv),N(sv.capRecv)],color:'#9db4e0'},{name:'Salvaged',data:[N(sv.valveSalv),N(sv.capSalv)],color:'#1a9e55'},{name:'Scrapped',data:[N(sv.valveScrap),N(sv.capScrap)],color:'#d93636'}],{vals:true})}</div>
 <div class="card"><h3>Defective Cylinders & Repairs</h3>${chart(['DPT','HR','Body Leak','Bung Leak','Evacuated','PT Sent','PT Received','Cold Repair'],[{name:'Nos.',data:[r.dpt,r.hr,r.bodyLeak,r.bungLeak,r.evac,r.ptSent,r.ptRecv,r.cold],color:'#7b4bc4'}],{vals:true,rot:true})}</div>
 <div class="card"><h3>Cylinder Stock – Filled / Empty / Defective</h3>${chart(CYL.map(c=>c.n),[{name:'Filled',data:CYL.map(c=>N((r.stock[c.k]||{}).filled)),color:'#1a9e55'},{name:'Empty',data:CYL.map(c=>N((r.stock[c.k]||{}).empty)),color:'#9db4e0'},{name:'Defective',data:CYL.map(c=>N((r.stock[c.k]||{}).def)),color:'#d93636'}],{stack:true})}</div>
 <div class="card"><h3>Production Loss by Tag (min)</h3>${Object.keys(r.lossByTag).length?pie(Object.keys(r.lossByTag),Object.values(r.lossByTag),{colors:['#d93636','#e69500','#7b4bc4','#14a3b8','#0b3c8c','#5b6475']}):'<p class="desc">No loss recorded. ✅</p>'}</div>
 </div>`};

VIEWS.trends=()=>{const m=M(),ms=monthSum(m),s=S(),t=s.t,dl=ms.days.map(d=>d.date.slice(8));
 const months=prevMonths(m,12),ar=months.map(monthSum),ml=months.map(monthName);
 const pct=(d,c)=>d.nos?+(N((d.cons[c]||{}).consumed)/d.nos*100).toFixed(2):null;
 const tags=Object.entries(ms.lossByTag).sort((a,b)=>b[1]-a[1]);let cum=0;const totL=tags.reduce((a,x)=>a+x[1],0);
 const rv=get(mk(m,'revex'),{});
 return head('Monthly Trends – '+monthName(m),'Day-wise trends for the selected month and 12-month comparison.')+
 `<div class="grid2">
 <div class="card"><h3>Day-wise Bottling (MT) vs Target</h3>${chart(dl,CYL.map((c,i)=>({name:c.n,data:ms.days.map(d=>+(d.cyl[c.k]*c.kg/1000).toFixed(2)),color:COLORS[i]})),{stack:true,target:t.dailyMT})}</div>
 <div class="card"><h3>Day-wise Filling Accuracy %</h3>${chart(dl,[{name:'Accuracy %',type:'line',data:ms.days.map(d=>d.acc===null?null:+d.acc.toFixed(2)),color:'#1a9e55'}],{target:t.fillAcc,yMin:95})}</div>
 <div class="card"><h3>Day-wise Trucks Reported vs Lorries Filled</h3>${chart(dl,[{name:'Trucks Reported',data:ms.days.map(d=>d.trucks),color:'#0b3c8c'},{name:'Lorries Filled',data:ms.days.map(d=>d.lorries),color:'#f0b400'}])}</div>
 <div class="card"><h3>Day-wise Lorry Invoices – Sales Area</h3>${chart(dl,s.salesAreas.map((a,i)=>({name:a,data:ms.days.map(d=>(d.inv[a]||{}).lorries||0),color:COLORS[i]})),{stack:true})}</div>
 <div class="card"><h3>Electricity – kWh & kWh/MT</h3>${chart(dl,[{name:'kWh',data:ms.days.map(d=>d.kwh+d.dgKwh),color:'#14a3b8'},{name:'kWh/MT',type:'line',right:true,data:ms.days.map(d=>d.kwhMT===null?null:+d.kwhMT.toFixed(2)),color:'#d93636'}],{right:true})}</div>
 <div class="card"><h3>SC Valve / Delrin Cap / O-Ring Consumption (% of bottling)</h3>${chart(dl,[{name:'SC Valve %',type:'line',data:ms.days.map(d=>pct(d,'SC Valves')),color:'#d93636'},{name:'Delrin Cap %',type:'line',data:ms.days.map(d=>pct(d,'Delrin Caps')),color:'#0b3c8c'},{name:'O-Ring %',type:'line',data:ms.days.map(d=>pct(d,'O-Rings')),color:'#1a9e55'}])}</div>
 <div class="card"><h3>DPT / HR Generation & PT Received</h3>${chart(dl,[{name:'DPT',data:ms.days.map(d=>d.dpt),color:'#7b4bc4'},{name:'HR',data:ms.days.map(d=>d.hr),color:'#e69500'},{name:'PT Received',type:'line',data:ms.days.map(d=>d.ptRecv),color:'#0b3c8c'}])}</div>
 <div class="card"><h3>Production Loss Pareto (minutes)</h3>${tags.length?chart(tags.map(x=>x[0]),[{name:'Minutes',data:tags.map(x=>x[1]),color:'#d93636'},{name:'Cumulative %',type:'line',right:true,data:tags.map(x=>{cum+=x[1];return +(cum/totL*100).toFixed(1)}),color:'#0b3c8c'}],{right:true,rot:true,h:300}):'<p class="desc">No loss in this month.</p>'}</div>
 <div class="card"><h3>Revex Share by Cost Head</h3>${ms.revex?pie(s.revexHeads,s.revexHeads.map(h=>N((rv[h]||{}).act)),{h:300}):'<p class="desc">Revex not entered.</p>'}</div>
 <div class="card"><h3>12-Month Bottling (MT) vs Cost (Rs/MT)</h3>${chart(ml,[{name:'Bottling MT',data:ar.map(x=>+x.mt.toFixed(1)),color:'#0b3c8c'},{name:'Rs/MT',type:'line',right:true,data:ar.map(x=>x.rsMT?+x.rsMT.toFixed(0):null),color:'#d93636'}],{right:true,rot:true,h:300})}</div>
 <div class="card"><h3>12-Month PT Cylinders vs Paint (Ltr)</h3>${chart(ml,[{name:'PT Cylinders',data:ar.map(x=>x.ptRecv),color:'#0b3c8c'},{name:'Red Paint (Ltr)',type:'line',right:true,data:ar.map(x=>N((x.cons['Red Paint (Ltr)']||{}).consumed)),color:'#d93636'}],{right:true,rot:true,h:300})}</div>
 <div class="card"><h3>12-Month Revex vs Capex (Rs)</h3>${chart(ml,[{name:'Revex',data:ar.map(x=>x.revex),color:'#0b3c8c'},{name:'Capex',data:ar.map(x=>x.capex),color:'#f0b400'}],{rot:true,h:300})}</div>
 </div>`};

VIEWS.start=()=>{const k=dk(D(),'start');{const x=get(k,{});if(x.stdA===undefined){x.stdA='06:00';x.stdB='14:00';STORE[k]=x;persist()}}return head('Plant Start Time – '+dateLbl(),'Record scheduled and actual start, and the time of first cylinder introduction for each shift (6 AM–2 PM and 2 PM–10 PM).')+
 `<div class="card"><div class="fg">
 <label>Shift A – Scheduled Start ${I(k,'stdA','time')}</label><label>Shift A – Plant Start (Actual) ${I(k,'actA','time')}</label><label>Shift A – First Cylinder Introduction ${I(k,'introA','time')}</label><label>Shift A – Shift Incharge ${I(k,'inchA','text')}</label>
 <label>Shift B – Scheduled Start ${I(k,'stdB','time')}</label><label>Shift B – Plant Start (Actual) ${I(k,'actB','time')}</label><label>Shift B – First Cylinder Introduction ${I(k,'introB','time')}</label><label>Shift B – Shift Incharge ${I(k,'inchB','text')}</label>
 <label>Plant Stop Time ${I(k,'stop','time')}</label><label>Carousel / Line No. ${I(k,'line','text')}</label></div>
 <div style="margin-top:10px"><label class="desc">Remarks / Reason for delay</label>${I(k,'rem','text','style="width:100%"')}</div></div>`};

VIEWS.manpower=()=>{const k=dk(D(),'manpower'),s=S(),r=daySum(D());
 return head('Manpower – Work-wise – '+dateLbl(),'Number of persons deployed against each work point, shift-wise.')+
 `<div class="card tw"><table><tr><th class="l">Work / Point</th><th>Required</th><th>Shift A</th><th>Shift B</th><th>Total</th><th>Shortfall</th><th class="l">Remarks</th></tr>
 ${s.manpower.map(m=>{const x=get(k,{})[m]||{};const tot=N(x.A)+N(x.B),sf=N(x.req)*2-tot;return `<tr><td class="l">${esc(m)}</td><td>${I(k,m+'.req')}</td><td>${I(k,m+'.A')}</td><td>${I(k,m+'.B')}</td><td><b>${tot}</b></td><td class="${sf>0?'bad':''}">${N(x.req)?sf:''}</td><td>${I(k,m+'.rem','text')}</td></tr>`}).join('')}
 <tr class="tot"><td class="l">TOTAL</td><td></td><td>${r.mpA}</td><td>${r.mpB}</td><td>${r.mpA+r.mpB}</td><td></td><td></td></tr></table>
 <p class="desc">Required = persons needed per shift. Shortfall = (Required × 2) − Total.</p></div>`};

VIEWS.equip=()=>{const k=dk(D(),'equip'),s=S(),eq=get(k,{});
 return head('Morning Shift – Equipment Working Report – '+dateLbl(),'To be updated by the Shed Officer by 7:00 AM.')+
 `<div class="row noprint"><button class="btn s" onclick="allWorking()">Mark all blank as "Working"</button></div>
 <div class="card tw"><table><tr><th>#</th><th class="l">Equipment</th><th>Status</th><th>Checked at</th><th class="l">Problem / Remarks</th><th>Expected Rectification</th></tr>
 ${s.equipment.map((q,i)=>{const st=(eq[q]||{}).st;const c=st==='Working'?'t-ok':st==='Not Working'?'t-bad':st?'t-w':'t-n';
  return `<tr><td>${i+1}</td><td class="l">${esc(q)} <span class="tag ${c}">${esc(st||'Not updated')}</span></td><td>${SEL(k,q+'.st',['Working','Not Working','Under Maintenance','Standby'])}</td><td>${I(k,q+'.t','time')}</td><td>${I(k,q+'.rem','text')}</td><td>${I(k,q+'.eta','text')}</td></tr>`}).join('')}</table></div>`};
function allWorking(){const k=dk(D(),'equip'),o=clone(get(k,{}));S().equipment.forEach(q=>{o[q]=o[q]||{};if(!o[q].st)o[q].st='Working'});set(k,o);render()}

VIEWS.hourly=()=>{const d=D(),k=dk(d,'hourly'),r=daySum(d),h=get(k,{}),nowH=new Date().getHours(),isT=d===todayStr();
 const tot=f=>HOURS.reduce((a,x)=>a+N((h[x]||{})[f]),0);
 return head('Hourly Production, SQC, Trucks & Lorries – '+dateLbl(),'06:00 to 22:00 hrs. Enter cylinders filled type-wise, SQC result and truck movement every hour. Current hour is highlighted.')+
 `<div class="card tw"><table><tr><th rowspan="2">Hour</th><th colspan="${CYL.length+2}">Production (Nos.)</th><th colspan="6">SQC Report</th><th colspan="2">Trucks</th></tr>
 <tr>${CYL.map(c=>`<th>${c.n}</th>`).join('')}<th>Total</th><th>MT</th><th>Checked</th><th>Within Tol.</th><th>Under-wt</th><th>Over-wt</th><th>Leak</th><th>Accuracy %</th><th>Reported</th><th>Lorries Filled</th></tr>
 ${HOURS.map(x=>{const y=h[x]||{};const n=CYL.reduce((a,c)=>a+N(y[c.k]),0),mt=CYL.reduce((a,c)=>a+N(y[c.k])*c.kg/1000,0),ac=N(y.sqcChk)?N(y.sqcOk)/N(y.sqcChk)*100:null;
 return `<tr class="${isT&&parseInt(x)===nowH?'now':''}"><td><b>${x}</b></td>${CYL.map(c=>`<td>${I(k,x+'.'+c.k)}</td>`).join('')}<td><b>${fmt(n)}</b></td><td>${fmt(mt,2)}</td>
 <td>${I(k,x+'.sqcChk')}</td><td>${I(k,x+'.sqcOk')}</td><td>${I(k,x+'.under')}</td><td>${I(k,x+'.over')}</td><td>${I(k,x+'.leak')}</td><td class="${ac===null?'':ac>=S().t.fillAcc?'ok':'bad'}">${ac===null?'':fmt(ac,2)}</td>
 <td>${I(k,x+'.trucks')}</td><td>${I(k,x+'.lorries')}</td></tr>`}).join('')}
 <tr class="tot"><td>TOTAL</td>${CYL.map(c=>`<td>${fmt(r.cyl[c.k])}</td>`).join('')}<td>${fmt(r.nos)}</td><td>${fmt(r.mt,2)}</td><td>${fmt(r.sqcChk)}</td><td>${fmt(r.sqcOk)}</td><td>${tot('under')}</td><td>${tot('over')}</td><td>${tot('leak')}</td><td>${r.acc===null?'':fmt(r.acc,2)}</td><td>${r.trucks}</td><td>${r.lorries}</td></tr></table>
 <p class="desc">Filling accuracy = cylinders within tolerance ÷ cylinders checked × 100. MT = Σ(nos × net kg) ÷ 1000.</p></div>`};

VIEWS.loss=()=>{const k=dk(D(),'loss'),s=S(),a=get(k,[]),r=daySum(D());
 return head('Production Loss – '+dateLbl(),'Log each stoppage with time, a specific tag, equipment and cause. Duration is calculated automatically.')+
 `<div class="row noprint"><button class="btn" onclick="listAdd('${k}',{from:'',to:'',tag:'',shift:'A'})">+ Add Loss Event</button></div>
 <div class="card tw"><table><tr><th>#</th><th>Shift</th><th>From</th><th>To</th><th>Duration (min)</th><th>Loss Tag</th><th>Equipment</th><th>Cyl. Loss (est.)</th><th class="l">Root Cause / Action Taken</th><th>Reported By</th><th></th></tr>
 ${a.map((l,i)=>`<tr><td>${i+1}</td><td>${LS_(k,i,'shift',l.shift,['A','B'])}</td><td>${LI(k,i,'from',l.from,'time')}</td><td>${LI(k,i,'to',l.to,'time')}</td><td><b>${mins(l.from,l.to)}</b></td><td>${LS_(k,i,'tag',l.tag,s.lossTags)}</td><td>${LS_(k,i,'eq',l.eq,s.equipment)}</td><td>${LI(k,i,'cyl',l.cyl,'number')}</td><td>${LI(k,i,'rem',l.rem)}</td><td>${LI(k,i,'by',l.by)}</td><td><button class="btn x" onclick="listDel('${k}',${i})">✕</button></td></tr>`).join('')||'<tr><td colspan="11" class="desc">No loss events recorded.</td></tr>'}
 <tr class="tot"><td colspan="4">TOTAL</td><td>${r.lossMin}</td><td colspan="2"></td><td>${r.lossCyl}</td><td colspan="3"></td></tr></table></div>
 <div class="card"><h3>Tag-wise Summary</h3><table><tr><th class="l">Tag</th><th>Minutes</th><th>Hours</th></tr>${Object.entries(r.lossByTag).map(([t,m])=>`<tr><td class="l">${esc(t)}</td><td>${m}</td><td>${fmt(m/60,2)}</td></tr>`).join('')}</table></div>`};

VIEWS.cons=()=>{const k=dk(D(),'cons'),s=S(),r=daySum(D());
 return head('Daily Consumables Issued – '+dateLbl(),'Shift-wise issue and consumption of consumables (as per Daily Shift Operation & Consumption Register).')+
 `<div class="card tw"><table><tr><th class="l">Consumable</th><th>Opening Stock</th><th>Issued – A</th><th>Issued – B</th><th>Total Issued</th><th>Consumed</th><th>% of Bottling (Nos.)</th><th>Closing</th><th class="l">Remarks</th></tr>
 ${s.consumables.map(c=>{const x=get(k,{})[c]||{};const iss=N(x.iA)+N(x.iB);const pct=r.nos?N(x.consumed)/r.nos*100:null;
 return `<tr><td class="l">${esc(c)}</td><td>${I(k,c+'.open')}</td><td>${I(k,c+'.iA',undefined,'')}</td><td>${I(k,c+'.iB')}</td><td><b>${fmt(iss,1)}</b></td><td>${I(k,c+'.consumed')}</td><td>${/Ltr|Kg/.test(c)||pct===null?'':fmt(pct,2)+'%'}</td><td>${x.open!==undefined&&x.open!==''?fmt(N(x.open)-N(x.consumed),1):''}</td><td>${I(k,c+'.rem','text')}</td></tr>`}).join('')}
 </table><p class="desc">Total Issued is stored automatically for monthly reports. Benchmarks: SC Valve ≤ ${s.t.scValvePct}% and Delrin Cap ≤ ${s.t.delrinPct}% of bottling.</p></div>`};

VIEWS.salvage=()=>{const k=dk(D(),'salvage');const x=get(k,{});
 return head('Valve Salvaged & Cap Salvaging Report – '+dateLbl(),'Defective SC valves and Delrin caps received, salvaged (reusable) and scrapped.')+
 `<div class="card tw"><table><tr><th class="l">Item</th><th>Received for Salvage</th><th>Salvaged / Reused</th><th>Scrapped</th><th>Pending</th><th>Salvage %</th><th class="l">Remarks</th></tr>
 <tr><td class="l">SC Valves</td><td>${I(k,'valveRecv')}</td><td>${I(k,'valveSalv')}</td><td>${I(k,'valveScrap')}</td><td>${N(x.valveRecv)-N(x.valveSalv)-N(x.valveScrap)}</td><td>${N(x.valveRecv)?fmt(N(x.valveSalv)/N(x.valveRecv)*100,1)+'%':''}</td><td>${I(k,'valveRem','text')}</td></tr>
 <tr><td class="l">Delrin Caps</td><td>${I(k,'capRecv')}</td><td>${I(k,'capSalv')}</td><td>${I(k,'capScrap')}</td><td>${N(x.capRecv)-N(x.capSalv)-N(x.capScrap)}</td><td>${N(x.capRecv)?fmt(N(x.capSalv)/N(x.capRecv)*100,1)+'%':''}</td><td>${I(k,'capRem','text')}</td></tr></table></div>`};

VIEWS.dpt=()=>{const k=dk(D(),'dpt');
 return head('DPT / HR Generation, Pressure Tested Cylinders & Cold Repair – '+dateLbl(),'Defective cylinders segregated, PT cylinders received back and cold repair carried out.')+
 `<div class="card"><div class="fg">
 <label>DPT Cylinders Generated (Nos.) ${I(k,'dpt')}</label><label>HR Cylinders Generated (Nos.) ${I(k,'hr')}</label>
 <label>Body Leak Cylinders Found ${I(k,'bodyLeak')}</label><label>Bung Leak Cylinders Found ${I(k,'bungLeak')}</label><label>Evacuation Done (Nos.) ${I(k,'evac')}</label>
 <label>Cylinders Sent for Pressure Testing ${I(k,'ptSent')}</label><label>Pressure Tested Cylinders Received ${I(k,'ptRecv')}</label>
 <label>Cold Repair Done (Nos.) ${I(k,'cold')}</label><label>Cold Repair – Rejected ${I(k,'coldRej')}</label>
 <label>All defective cylinders corrected? ${SEL(k,'corrected',['YES','NO'])}</label></div>
 <div style="margin-top:10px"><label class="desc">Remarks</label>${I(k,'rem','text','style="width:100%"')}</div></div>`};

VIEWS.invoice=()=>{const k=dk(D(),'invoice'),s=S(),a=get(k,[]),r=daySum(D());
 return head('Sales Area-wise Lorry Invoice – '+dateLbl(),'Each filled lorry invoiced to '+s.salesAreas.join(' / ')+'. Lorry capacity norm: '+s.t.lorryCap+' cylinders.')+
 `<div class="row noprint">${s.salesAreas.map(x=>`<button class="btn" onclick="listAdd('${k}',{area:'${esc(x)}',time:new Date().toTimeString().slice(0,5)})">+ ${esc(x)} Lorry</button>`).join('')}</div>
 <div class="card tw"><table><tr><th>#</th><th>Sales Area</th><th>Time</th><th>Lorry No.</th><th>Invoice No.</th><th>Distributor / Market</th>${CYL.map(c=>`<th>${c.n}</th>`).join('')}<th>Total</th><th>MT</th><th></th></tr>
 ${a.map((x,i)=>{const n=CYL.reduce((a,c)=>a+N(x[c.k]),0),mt=CYL.reduce((a,c)=>a+N(x[c.k])*c.kg/1000,0);return `<tr><td>${i+1}</td><td>${LS_(k,i,'area',x.area,s.salesAreas)}</td><td>${LI(k,i,'time',x.time,'time')}</td><td>${LI(k,i,'lorry',x.lorry)}</td><td>${LI(k,i,'inv',x.inv)}</td><td>${LI(k,i,'dist',x.dist)}</td>${CYL.map(c=>`<td>${LI(k,i,c.k,x[c.k],'number')}</td>`).join('')}<td><b>${n}</b></td><td>${fmt(mt,2)}</td><td><button class="btn x" onclick="listDel('${k}',${i})">✕</button></td></tr>`}).join('')||`<tr><td colspan="${CYL.length+9}" class="desc">No invoices yet.</td></tr>`}</table></div>
 <div class="card"><h3>Sales Area Summary</h3><table><tr><th class="l">Sales Area</th><th>Lorries</th><th>Cylinders</th><th>MT</th></tr>${Object.entries(r.inv).map(([a,v])=>`<tr><td class="l">${esc(a)}</td><td>${v.lorries}</td><td>${fmt(v.nos)}</td><td>${fmt(v.mt,2)}</td></tr>`).join('')}
 <tr class="tot"><td class="l">TOTAL</td><td>${r.invCount}</td><td>${fmt(Object.values(r.inv).reduce((a,v)=>a+v.nos,0))}</td><td>${fmt(Object.values(r.inv).reduce((a,v)=>a+v.mt,0),2)}</td></tr></table></div>`};

VIEWS.elec=()=>{const k=dk(D(),'elec'),r=daySum(D()),t=S().t;
 return head('Electricity Consumption – '+dateLbl(),'Energy meter readings. kWh = (Closing − Opening) × Multiplying Factor.')+
 `<div class="card"><div class="fg"><label>Opening Reading (kWh) ${I(k,'open')}</label><label>Closing Reading (kWh) ${I(k,'close')}</label><label>Multiplying Factor (MF) ${I(k,'mf')}</label>
 <label>Max Demand (kVA) ${I(k,'md')}</label><label>Power Factor ${I(k,'pf')}</label><label>DG Generation (kWh) ${I(k,'dg')}</label><label>DG Running Hours ${I(k,'dgh')}</label><label>Power Failure Duration (min) ${I(k,'pfail')}</label></div></div>
 <div class="kpis">${kpi('Grid Consumption',fmt(r.kwh,1)+' kWh','')}${kpi('DG Generation',fmt(r.dgKwh,1)+' kWh','')}${kpi('Specific Consumption',r.kwhMT===null?'—':fmt(r.kwhMT,2)+' kWh/MT','Target '+t.kwhPerMT,r.kwhMT===null?'':r.kwhMT<=t.kwhPerMT?'g':'r')}</div>`};

VIEWS.stock=()=>{const k=dk(D(),'stock'),x=get(k,{});
 return head('Cylinder Stock Position – '+dateLbl(),'Closing stock at end of day (or update in real time).')+
 `<div class="card tw"><table><tr><th class="l">Type</th><th>Filled</th><th>Empty</th><th>Defective (DPT/HR/VCM)</th><th>Total</th></tr>
 ${CYL.map(c=>{const y=x[c.k]||{};return `<tr><td class="l">${c.n}</td><td>${I(k,c.k+'.filled')}</td><td>${I(k,c.k+'.empty')}</td><td>${I(k,c.k+'.def')}</td><td><b>${fmt(N(y.filled)+N(y.empty)+N(y.def))}</b></td></tr>`}).join('')}
 <tr class="tot"><td class="l">TOTAL</td>${['filled','empty','def'].map(f=>`<td>${fmt(CYL.reduce((a,c)=>a+N((x[c.k]||{})[f]),0))}</td>`).join('')}<td>${fmt(CYL.reduce((a,c)=>a+N((x[c.k]||{}).filled)+N((x[c.k]||{}).empty)+N((x[c.k]||{}).def),0))}</td></tr></table></div>
 <div class="card"><div class="fg"><label>DPT Inventory (Cyls) ${I(k,'dptInv')}</label><label>HR Inventory (Cyls) ${I(k,'hrInv')}</label><label>Bulk LPG Stock (MT) ${I(k,'bulk')}</label><label>Stock as on (time) ${I(k,'time','time')}</label></div></div>`};

VIEWS.daily=()=>{const d=D(),r=daySum(d),s=S(),st=r.start,eq=get(dk(d,'equip'),{});
 const nw=s.equipment.filter(q=>['Not Working','Under Maintenance'].includes((eq[q]||{}).st));
 return `<div class="row noprint"><button class="btn" onclick="print()">🖨 Print / Save PDF</button></div>
 <div class="card"><div class="mis-h">${esc(s.plantName)} – Daily Operations Report – ${dateLbl()}</div>
 <table><tr><th class="l" colspan="4">1. Plant Start & Manpower</th></tr>
 <tr><td class="l">Shift A start / Cyl. intro</td><td>${st.actA||'—'} / ${st.introA||'—'}</td><td class="l">Shift B start / Cyl. intro</td><td>${st.actB||'—'} / ${st.introB||'—'}</td></tr>
 <tr><td class="l">Manpower Shift A</td><td>${r.mpA}</td><td class="l">Manpower Shift B</td><td>${r.mpB}</td></tr>
 <tr><th class="l" colspan="4">2. Production & Quality</th></tr>
 ${CYL.map(c=>`<tr><td class="l">${c.n} filled</td><td>${fmt(r.cyl[c.k])}</td><td class="l">MT</td><td>${fmt(r.cyl[c.k]*c.kg/1000,2)}</td></tr>`).join('')}
 <tr class="tot"><td class="l">Total Cylinders</td><td>${fmt(r.nos)}</td><td class="l">Total MT</td><td>${fmt(r.mt,2)}</td></tr>
 <tr><td class="l">SQC checked / Filling accuracy</td><td>${fmt(r.sqcChk)} / ${r.acc===null?'—':fmt(r.acc,2)+'%'}</td><td class="l">Trucks reported / Lorries filled</td><td>${r.trucks} / ${r.lorries}</td></tr>
 ${Object.entries(r.inv).map(([a,v])=>`<tr><td class="l">Invoice – ${esc(a)}</td><td>${v.lorries} lorries</td><td class="l">Cylinders / MT</td><td>${fmt(v.nos)} / ${fmt(v.mt,2)}</td></tr>`).join('')}
 <tr><th class="l" colspan="4">3. Defective Cylinders, Salvage & Repairs</th></tr>
 <tr><td class="l">DPT / HR generated</td><td>${r.dpt} / ${r.hr}</td><td class="l">PT cylinders received</td><td>${r.ptRecv}</td></tr>
 <tr><td class="l">Valves salvaged / scrapped</td><td>${r.valveSalv} / ${r.valveScrap}</td><td class="l">Caps salvaged / scrapped</td><td>${r.capSalv} / ${r.capScrap}</td></tr>
 <tr><td class="l">Cold repair done</td><td>${r.cold}</td><td class="l">Evacuation done</td><td>${r.evac}</td></tr>
 <tr><th class="l" colspan="4">4. Utilities</th></tr><tr><td class="l">Electricity (Grid + DG)</td><td>${fmt(r.kwh+r.dgKwh,1)} kWh</td><td class="l">kWh/MT</td><td>${r.kwhMT===null?'—':fmt(r.kwhMT,2)}</td></tr>
 <tr><th class="l" colspan="4">5. Consumables Consumed</th></tr>
 ${s.consumables.map(c=>`<tr><td class="l">${esc(c)}</td><td>Issued: ${fmt(N((r.cons[c]||{}).issued),1)}</td><td class="l">Consumed</td><td>${fmt(N((r.cons[c]||{}).consumed),1)}</td></tr>`).join('')}
 <tr><th class="l" colspan="4">6. Production Loss (${r.lossMin} min)</th></tr>
 ${get(dk(d,'loss'),[]).map(l=>`<tr><td class="l">${l.from||''}–${l.to||''} (${mins(l.from,l.to)} min)</td><td>${esc(l.tag||'')}</td><td class="l">${esc(l.eq||'')}</td><td>${esc(l.rem||'')}</td></tr>`).join('')||'<tr><td colspan="4">NIL</td></tr>'}
 <tr><th class="l" colspan="4">7. Equipment Not Working / Under Maintenance</th></tr>
 ${nw.map(q=>`<tr><td class="l">${esc(q)}</td><td>${esc(eq[q].st)}</td><td class="l" colspan="2">${esc(eq[q].rem||'')}</td></tr>`).join('')||'<tr><td colspan="4">All equipment working</td></tr>'}
 </table><p style="margin-top:30px;display:flex;justify-content:space-between"><span>Shed Officer</span><span>Plant Officer</span><span>Plant Manager</span></p></div>`};

VIEWS.weekly=()=>{const ws=weekStart(D()),k='w:'+ws+':maint',s=S(),x=get(k,{});const we=new Date(ws+'T00:00');we.setDate(we.getDate()+6);
 const done=s.equipment.filter(q=>(x[q]||{}).st==='Done').length;
 return head('Weekly Maintenance Report – Equipment-wise','Week: '+new Date(ws+'T00:00').toLocaleDateString('en-IN')+' to '+we.toLocaleDateString('en-IN')+' (change the Date at top to switch week). Includes Sunday OLD/VLD gun servicing & alignment.')+
 `<div class="kpis">${kpi('Completed',`${done}/${s.equipment.length}`,'',done===s.equipment.length?'g':'y')}${kpi('Pending',s.equipment.filter(q=>(x[q]||{}).st==='Pending').length,'','r')}</div>
 <div class="card tw"><table><tr><th>#</th><th class="l">Equipment</th><th class="l">Maintenance Activity</th><th>Type</th><th>Date Done</th><th>Status</th><th>Done By</th><th>Spares Used</th><th>Downtime (hrs)</th><th class="l">Observations</th></tr>
 ${s.equipment.map((q,i)=>`<tr><td>${i+1}</td><td class="l">${esc(q)}</td><td>${I(k,q+'.act','text')}</td><td>${SEL(k,q+'.type',['Preventive','Breakdown','Predictive','Statutory'])}</td><td>${I(k,q+'.dt','date')}</td><td>${SEL(k,q+'.st',['Done','Pending','Partially Done','Not Due'])}</td><td>${I(k,q+'.by','text')}</td><td>${I(k,q+'.sp','text')}</td><td>${I(k,q+'.dh')}</td><td>${I(k,q+'.obs','text')}</td></tr>`).join('')}</table></div>`};

VIEWS.ptpaint=()=>{const m=M(),days=daysOfMonth(m),ms=monthSum(m),k=mk(m,'ptpaint'),x=get(k,{});
 const paint=consSum(days,'Red Paint (Ltr)'),primer=consSum(days,'Primer (Ltr)');const pt=N(x.ptOv)||ms.ptRecv,tp=paint+N(x.paintAdj),tpr=primer+N(x.primerAdj);
 const months=prevMonths(m,6);
 return head('Pressure Tested Cylinders vs Paint Consumption – '+monthName(m),'PT cylinder count taken from daily DPT/PT entries; paint & primer from daily consumables register.')+
 `<div class="kpis">${kpi('PT Cylinders Given / Received',fmt(pt),'Month total')}${kpi('Red Paint Consumed',fmt(tp,1)+' Ltr','')}${kpi('Primer Consumed',fmt(tpr,1)+' Ltr','')}
 ${kpi('Paint per Cylinder',pt?fmt(tp*1000/pt,0)+' ml':'—','Red paint')}${kpi('Primer per Cylinder',pt?fmt(tpr*1000/pt,0)+' ml':'—','')}${kpi('Cylinders per Litre Paint',tp?fmt(pt/tp,1):'—','')}</div>
 <div class="card"><h3>Manual adjustments (optional)</h3><div class="fg"><label>PT Cylinders override (if different) ${I(k,'ptOv')}</label><label>Paint adjustment (Ltr) ${I(k,'paintAdj')}</label><label>Primer adjustment (Ltr) ${I(k,'primerAdj')}</label><label>Std. paint norm (ml/cyl) ${I(k,'norm')}</label></div></div>
 <div class="card"><h3>Last 6 months</h3>${chart(months.map(monthName),[{name:'PT Cylinders',data:months.map(mm=>N(get(mk(mm,'ptpaint'),{}).ptOv)||monthSum(mm).ptRecv),color:'#0b3c8c'},{name:'Paint (Ltr)',type:'line',right:true,data:months.map(mm=>consSum(daysOfMonth(mm),'Red Paint (Ltr)')+N(get(mk(mm,'ptpaint'),{}).paintAdj)),color:'#d93636'}],{right:true,vals:true})}</div>
 <div class="card tw"><h3>Day-wise</h3><table><tr><th>Date</th><th>PT Sent</th><th>PT Received</th><th>Red Paint (Ltr)</th><th>Primer (Ltr)</th><th>ml/cyl</th></tr>
 ${days.map(d=>{const r=daySum(d),p=N((r.cons['Red Paint (Ltr)']||{}).consumed),q=N((r.cons['Primer (Ltr)']||{}).consumed);return(r.ptRecv||p||r.ptSent)?`<tr><td>${d.slice(8)}</td><td>${r.ptSent}</td><td>${r.ptRecv}</td><td>${fmt(p,1)}</td><td>${fmt(q,1)}</td><td>${r.ptRecv?fmt(p*1000/r.ptRecv,0):''}</td></tr>`:''}).join('')}
 <tr class="tot"><td>Total</td><td>${ms.ptSent}</td><td>${ms.ptRecv}</td><td>${fmt(paint,1)}</td><td>${fmt(primer,1)}</td><td>${ms.ptRecv?fmt(paint*1000/ms.ptRecv,0):''}</td></tr></table></div>`};

VIEWS.revex=()=>{const m=M(),k=mk(m,'revex'),s=S(),x=get(k,{}),ms=monthSum(m);
 return head('Monthly Revex Consumption – Head-wise – '+monthName(m),'Enter budget and actual expenditure in Rupees. Rs/MT uses month production from daily data.')+
 `<div class="card tw"><table><tr><th class="l">Cost Head</th><th>Budget (Rs)</th><th>Actual (Rs)</th><th>Variance (Rs)</th><th>% Utilised</th><th>Rs / MT</th><th>Share %</th><th class="l">Remarks</th></tr>
 ${s.revexHeads.map(h=>{const y=x[h]||{},b=N(y.bud),a=N(y.act);return `<tr><td class="l">${esc(h)}</td><td>${I(k,h+'.bud')}</td><td>${I(k,h+'.act')}</td><td class="${b&&a>b?'bad':'ok'}">${b?fmt(b-a):''}</td><td>${b?fmt(a/b*100,1)+'%':''}</td><td>${ms.mt?fmt(a/ms.mt,2):''}</td><td>${ms.revex?fmt(a/ms.revex*100,1):''}</td><td>${I(k,h+'.rem','text')}</td></tr>`}).join('')}
 <tr class="tot"><td class="l">TOTAL</td><td>${fmt(ms.revexBud)}</td><td>${fmt(ms.revex)}</td><td>${fmt(ms.revexBud-ms.revex)}</td><td>${ms.revexBud?fmt(ms.revex/ms.revexBud*100,1)+'%':''}</td><td>${ms.rsMT?fmt(ms.rsMT,2):''}</td><td>100</td><td></td></tr></table></div>
 <div class="card"><h3>Head-wise Actual (Rs)</h3>${chart(s.revexHeads,[{name:'Budget',data:s.revexHeads.map(h=>N((x[h]||{}).bud)),color:'#9db4e0'},{name:'Actual',data:s.revexHeads.map(h=>N((x[h]||{}).act)),color:'#0b3c8c'}],{rot:true,h:300})}</div>`};

VIEWS.capex=()=>{const m=M(),k=mk(m,'capex'),a=get(k,[]);
 const prev=prevMonths(m,12).slice(0,-1);
 return head('Monthly Capex Consumption – '+monthName(m),'Capex jobs with sanctioned amount, expenditure this month and cumulative booking.')+
 `<div class="row noprint"><button class="btn" onclick="listAdd('${k}',{})">+ Add Capex Job</button><button class="btn s" onclick="copyCapex()">Copy jobs from previous month</button></div>
 <div class="card tw"><table><tr><th>#</th><th class="l">Job / Project</th><th>AA / WBS No.</th><th>Sanctioned (Rs)</th><th>PO Value (Rs)</th><th>Spent this Month (Rs)</th><th>Cumulative Spent (Rs)</th><th>% Utilised</th><th>Status</th><th>Target Date</th><th></th></tr>
 ${a.map((x,i)=>`<tr><td>${i+1}</td><td>${LI(k,i,'job',x.job)}</td><td>${LI(k,i,'aa',x.aa)}</td><td>${LI(k,i,'san',x.san,'number')}</td><td>${LI(k,i,'po',x.po,'number')}</td><td>${LI(k,i,'month',x.month,'number')}</td><td>${LI(k,i,'cum',x.cum,'number')}</td><td>${N(x.san)?fmt(N(x.cum)/N(x.san)*100,1)+'%':''}</td><td>${LS_(k,i,'st',x.st,['Not Started','Tendering','PO Placed','In Progress','Completed','Capitalised'])}</td><td>${LI(k,i,'td',x.td,'date')}</td><td><button class="btn x" onclick="listDel('${k}',${i})">✕</button></td></tr>`).join('')||'<tr><td colspan="11" class="desc">No capex jobs added.</td></tr>'}
 <tr class="tot"><td colspan="3">TOTAL</td><td>${fmt(a.reduce((s,x)=>s+N(x.san),0))}</td><td>${fmt(a.reduce((s,x)=>s+N(x.po),0))}</td><td>${fmt(a.reduce((s,x)=>s+N(x.month),0))}</td><td>${fmt(a.reduce((s,x)=>s+N(x.cum),0))}</td><td colspan="4"></td></tr></table></div>`};
function copyCapex(){const m=M(),p=prevMonths(m,2)[0];const a=get(mk(p,'capex'),[]).map(x=>({...x,month:0}));if(!a.length)return toast('No jobs in previous month');set(mk(m,'capex'),a);render()}

VIEWS.cost=()=>{const m=M(),ms=monthSum(m),s=S(),k=mk(m,'prodOverride'),rv=get(mk(m,'revex'),{}),months=prevMonths(m,12),ar=months.map(monthSum);
 return head('Production vs Cost Analysis (Rs/MT) – '+monthName(m),'Operating cost per MT = Total Revex actual ÷ Bottling (MT). Target Rs '+s.t.costPerMT+'/MT.')+
 `<div class="kpis">${kpi('Bottling',fmt(ms.mt,2)+' MT',fmt(ms.nos)+' cylinders')}${kpi('Revex (Actual)','Rs '+fmt(ms.revex),'')}
 ${kpi('Cost per MT',ms.rsMT?'Rs '+fmt(ms.rsMT,2):'—','Target Rs '+s.t.costPerMT,ms.rsMT?ms.rsMT<=s.t.costPerMT?'g':'r':'')}${kpi('Capex this month','Rs '+fmt(ms.capex),'')}
 ${kpi('Power',ms.kwhMT?fmt(ms.kwhMT,2)+' kWh/MT':'—','Target '+s.t.kwhPerMT)}</div>
 <div class="card"><div class="fg"><label>Override bottling MT (use if official figure differs) ${I(k,'mt')}</label></div></div>
 <div class="card"><h3>12-Month Trend – Bottling (MT) vs Cost (Rs/MT)</h3>${chart(months.map(monthName),[{name:'Bottling MT',data:ar.map(x=>+x.mt.toFixed(1)),color:'#0b3c8c'},{name:'Rs/MT',type:'line',right:true,data:ar.map(x=>x.rsMT?+x.rsMT.toFixed(0):null),color:'#d93636'}],{right:true,rot:true,h:300})}</div>
 <div class="card tw"><h3>Head-wise Rs/MT</h3><table><tr><th class="l">Cost Head</th><th>Actual (Rs)</th><th>Rs/MT</th></tr>${s.revexHeads.map(h=>`<tr><td class="l">${esc(h)}</td><td>${fmt(N((rv[h]||{}).act))}</td><td>${ms.mt?fmt(N((rv[h]||{}).act)/ms.mt,2):''}</td></tr>`).join('')}
 <tr class="tot"><td class="l">TOTAL</td><td>${fmt(ms.revex)}</td><td>${ms.rsMT?fmt(ms.rsMT,2):''}</td></tr></table></div>
 <div class="card tw"><h3>Month-wise table</h3><table><tr><th>Month</th><th>Cylinders</th><th>MT</th><th>Revex (Rs)</th><th>Rs/MT</th><th>Capex (Rs)</th><th>kWh/MT</th></tr>${ar.map(x=>`<tr><td>${monthName(x.m)}</td><td>${fmt(x.nos)}</td><td>${fmt(x.mt,2)}</td><td>${fmt(x.revex)}</td><td class="${x.rsMT&&x.rsMT>s.t.costPerMT?'bad':''}">${x.rsMT?fmt(x.rsMT,2):''}</td><td>${fmt(x.capex)}</td><td>${x.kwhMT?fmt(x.kwhMT,2):''}</td></tr>`).join('')}</table></div>`};

VIEWS.mis=()=>{const m=M(),ms=monthSum(m),s=S(),t=s.t;
 const pc=(c)=>ms.nos?N((ms.cons[c]||{}).consumed)/ms.nos*100:null;
 const sc=pc('SC Valves'),dl=pc('Delrin Caps'),orr=pc('O-Rings');
 const tags=Object.entries(ms.lossByTag).sort((a,b)=>b[1]-a[1]);
 const cr=get('customReports',[]);
 return `<div class="row noprint"><button class="btn" onclick="print()">🖨 Print / Save PDF</button><button class="btn s" onclick="exportMIS()">⬇ Export MIS (CSV)</button></div>
 <div class="card"><div class="mis-h">${esc(s.plantName)} – Monthly MIS Report – ${monthName(m)}</div>
 <table>
 <tr><th class="l" colspan="4">A. Bottling Performance</th></tr>
 <tr><td class="l">Working days</td><td>${ms.work}</td><td class="l">Total bottling</td><td><b>${fmt(ms.mt,2)} MT</b> (${fmt(ms.nos)} cyl)</td></tr>
 ${CYL.map(c=>`<tr><td class="l">${c.n}</td><td>${fmt(ms.cyl[c.k])} cyl</td><td class="l">MT</td><td>${fmt(ms.cyl[c.k]*c.kg/1000,2)}</td></tr>`).join('')}
 <tr><td class="l">Avg bottling / working day</td><td>${ms.work?fmt(ms.mt/ms.work,2):'—'} MT</td><td class="l">Filling accuracy (SQC)</td><td class="${ms.acc!==null&&ms.acc<t.fillAcc?'bad':'ok'}">${ms.acc===null?'—':fmt(ms.acc,2)+'%'} (${fmt(ms.sqcChk)} checked)</td></tr>
 <tr><th class="l" colspan="4">B. Despatch</th></tr>
 <tr><td class="l">Trucks reported</td><td>${fmt(ms.trucks)}</td><td class="l">Lorries filled</td><td>${fmt(ms.lorries)}</td></tr>
 ${Object.entries(ms.inv).map(([a,v])=>`<tr><td class="l">Invoiced – ${esc(a)}</td><td>${v.lorries} lorries</td><td class="l">Cyl / MT</td><td>${fmt(v.nos)} / ${fmt(v.mt,2)}</td></tr>`).join('')}
 <tr><th class="l" colspan="4">C. Benchmarks</th></tr>
 <tr><td class="l">SC valve consumption (% of bottling)</td><td class="${sc!==null&&sc>t.scValvePct?'bad':'ok'}">${sc===null?'—':fmt(sc,2)+'%'}</td><td class="l">Target</td><td>${t.scValvePct}%</td></tr>
 <tr><td class="l">Delrin cap consumption (% of bottling)</td><td class="${dl!==null&&dl>t.delrinPct?'bad':'ok'}">${dl===null?'—':fmt(dl,2)+'%'}</td><td class="l">Target</td><td>${t.delrinPct}%</td></tr>
 <tr><td class="l">O-ring consumption (% of bottling)</td><td>${orr===null?'—':fmt(orr,2)+'%'}</td><td class="l">Power (kWh/MT)</td><td class="${ms.kwhMT&&ms.kwhMT>t.kwhPerMT?'bad':'ok'}">${ms.kwhMT?fmt(ms.kwhMT,2):'—'} (Target ${t.kwhPerMT})</td></tr>
 <tr><td class="l">Cost per MT</td><td class="${ms.rsMT&&ms.rsMT>t.costPerMT?'bad':'ok'}">${ms.rsMT?'Rs '+fmt(ms.rsMT,2):'—'}</td><td class="l">Target</td><td>Rs ${t.costPerMT}</td></tr>
 <tr><th class="l" colspan="4">D. Defective Cylinders & Salvage</th></tr>
 <tr><td class="l">DPT generated</td><td>${fmt(ms.dpt)}</td><td class="l">HR generated</td><td>${fmt(ms.hr)}</td></tr>
 <tr><td class="l">PT cylinders received</td><td>${fmt(ms.ptRecv)}</td><td class="l">Cold repair done</td><td>${fmt(ms.cold)}</td></tr>
 <tr><td class="l">Valves salvaged / scrapped</td><td>${fmt(ms.valveSalv)} / ${fmt(ms.valveScrap)}</td><td class="l">Caps salvaged / scrapped</td><td>${fmt(ms.capSalv)} / ${fmt(ms.capScrap)}</td></tr>
 <tr><th class="l" colspan="4">E. Utilities & Cost</th></tr>
 <tr><td class="l">Electricity (Grid)</td><td>${fmt(ms.kwh)} kWh</td><td class="l">DG generation</td><td>${fmt(ms.dgKwh)} kWh</td></tr>
 <tr><td class="l">Revex actual / budget</td><td>Rs ${fmt(ms.revex)}</td><td class="l">Budget</td><td>Rs ${fmt(ms.revexBud)}</td></tr>
 <tr><td class="l">Capex booked this month</td><td>Rs ${fmt(ms.capex)}</td><td class="l">PT cyl vs Red paint</td><td>${fmt(ms.ptRecv)} cyl / ${fmt(N((ms.cons['Red Paint (Ltr)']||{}).consumed),1)} Ltr</td></tr>
 <tr><th class="l" colspan="4">F. Production Loss (${fmt(ms.lossMin/60,1)} hrs, ~${fmt(ms.lossCyl)} cyl)</th></tr>
 ${tags.map(([g,v])=>`<tr><td class="l" colspan="2">${esc(g)}</td><td colspan="2">${fmt(v)} min (${fmt(v/60,1)} hrs)</td></tr>`).join('')||'<tr><td colspan="4">NIL</td></tr>'}
 <tr><th class="l" colspan="4">G. Consumables</th></tr>
 ${s.consumables.map(c=>`<tr><td class="l">${esc(c)}</td><td>Issued ${fmt(ms.cons[c].issued,1)}</td><td class="l">Consumed</td><td>${fmt(ms.cons[c].consumed,1)}</td></tr>`).join('')}
 ${cr.map(rep=>{const v=get(mk(m,'cr:'+rep.id),{});return `<tr><th class="l" colspan="4">${esc(rep.name)}</th></tr>`+rep.fields.map(f=>`<tr><td class="l" colspan="2">${esc(f)}</td><td colspan="2">${esc(v[f]??'—')}</td></tr>`).join('')}).join('')}
 </table></div>
 <div class="card"><h3>Day-wise Bottling – ${monthName(m)}</h3>${chart(ms.days.map(d=>d.date.slice(8)),[...CYL.map((c,i)=>({name:c.n,data:ms.days.map(d=>+(d.cyl[c.k]*c.kg/1000).toFixed(2)),color:COLORS[i]}))],{stack:true,target:t.dailyMT})}</div>`};

VIEWS.custom=()=>{const m=M(),cr=get('customReports',[]);
 return head('Other Monthly Reports','Create your own monthly report formats (e.g., statutory, HSE, audit, inventory). Each report is filled month-wise, trended over 12 months and appears in the MIS automatically.')+
 `<div class="card noprint"><h3>Create new monthly report</h3><div class="fg"><label>Report name<input id="crN" placeholder="e.g. HSSE Monthly Report"></label><label style="grid-column:span 2">Fields (comma separated)<input id="crF" placeholder="e.g. Near misses, Safety trainings, Mock drills, Work permits issued"></label></div><div style="margin-top:8px"><button class="btn" onclick="addCR()">+ Create Report</button></div></div>
 ${cr.map((rep,ri)=>{const k=mk(m,'cr:'+rep.id),months=prevMonths(m,12);return `<div class="card tw"><h3>${esc(rep.name)} – ${monthName(m)} <button class="btn x noprint" style="margin-left:auto" onclick="delCR(${ri})">Delete report</button></h3>
 <div class="fg">${rep.fields.map(f=>`<label>${esc(f)} ${I(k,f,'text')}</label>`).join('')}</div>
 <h3 style="margin-top:14px">12-month view</h3><table><tr><th class="l">Field</th>${months.map(x=>`<th>${monthName(x)}</th>`).join('')}</tr>${rep.fields.map(f=>`<tr><td class="l">${esc(f)}</td>${months.map(x=>`<td>${esc(get(mk(x,'cr:'+rep.id),{})[f]??'')}</td>`).join('')}</tr>`).join('')}</table></div>`}).join('')}`};
function addCR(){const n=$('#crN').value.trim(),f=$('#crF').value.split(',').map(x=>x.trim()).filter(Boolean);if(!n||!f.length)return toast('Enter name and fields');const a=get('customReports',[]);a.push({id:Date.now().toString(36),name:n,fields:f});set('customReports',a);render()}
function delCR(i){if(!confirm('Delete this report format? (Data stays in backup)'))return;const a=get('customReports',[]);a.splice(i,1);set('customReports',a);render()}

VIEWS.export=()=>head('Export / Backup','Download data to Excel (CSV) or back up / restore the full database.')+
 `<div class="card"><h3>Daily summary (date range) → Excel</h3><div class="row"><label>From <input type="date" id="exF" value="${M()}-01"></label><label>To <input type="date" id="exT" value="${D()}"></label><button class="btn" onclick="exportRange()">⬇ Download CSV</button></div></div>
 <div class="card"><h3>Hourly data (selected date) → Excel</h3><button class="btn" onclick="exportHourly()">⬇ Hourly CSV for ${D()}</button></div>
 <div class="card"><h3>Full backup</h3><div class="row"><button class="btn" onclick="backup()">⬇ Download Backup (JSON)</button><label class="btn s">⬆ Restore Backup<input type="file" accept=".json" style="display:none" onchange="restore(this)"></label></div>
 <p class="desc">Take a backup weekly. In standalone mode data lives only in this browser.</p></div>
 <div class="card"><h3>Publish to GitHub (share with everyone)</h3>
 <ol style="margin:0;padding-left:18px;line-height:1.8"><li>Click <button class="btn" onclick="publishFile()">⬇ Download data.json</button></li>
 <li>Open your GitHub repository → folder <b>data</b> → <b>Add file → Upload files</b> → upload <b>data.json</b> (replace) → <b>Commit changes</b>.</li>
 <li>Within 1–2 minutes all users opening the website will see the updated data.</li></ol></div>
 <div class="card"><h3>Sample data</h3><div class="row"><button class="btn y" onclick="demo()">Load sample data (current month)</button><button class="btn d" onclick="wipe()">Clear ALL data</button></div></div>`;
function dl(name,text,type='text/csv'){const b=new Blob([type==='text/csv'?'\ufeff'+text:text],{type});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click()}
const csv=rows=>rows.map(r=>r.map(v=>{v=String(v??'');return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}).join(',')).join('\n');
function exportRange(){const f=$('#exF').value,t=$('#exT').value,s=S();const rows=[['Date','Shift A Intro','Shift B Intro','Manpower A','Manpower B','Eq Working','Eq Not Working',...CYL.map(c=>c.n),'Total Cyl','MT','SQC Checked','Accuracy %','Trucks Reported','Lorries Filled',...s.salesAreas.map(a=>'Invoice '+a+' (lorries)'),'Loss (min)','DPT','HR','PT Received','Cold Repair','Valve Salvaged','Cap Salvaged','kWh','DG kWh','kWh/MT',...s.consumables.map(c=>c+' consumed')]];
 for(let d=new Date(f+'T00:00');d<=new Date(t+'T00:00');d.setDate(d.getDate()+1)){const ds=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');const r=daySum(ds);
  rows.push([ds,r.start.introA,r.start.introB,r.mpA,r.mpB,r.eqW,r.eqNW,...CYL.map(c=>r.cyl[c.k]),r.nos,r.mt.toFixed(3),r.sqcChk,r.acc===null?'':r.acc.toFixed(2),r.trucks,r.lorries,...s.salesAreas.map(a=>(r.inv[a]||{}).lorries||0),r.lossMin,r.dpt,r.hr,r.ptRecv,r.cold,r.valveSalv,r.capSalv,r.kwh,r.dgKwh,r.kwhMT===null?'':r.kwhMT.toFixed(2),...s.consumables.map(c=>N((r.cons[c]||{}).consumed))])}
 dl(`HaldiaLPG_Daily_${f}_to_${t}.csv`,csv(rows))}
function exportHourly(){const d=D(),h=get(dk(d,'hourly'),{});const rows=[['Hour',...CYL.map(c=>c.n),'SQC Checked','Within Tol','Under','Over','Leak','Trucks Reported','Lorries Filled']];HOURS.forEach(x=>{const y=h[x]||{};rows.push([x,...CYL.map(c=>y[c.k]??''),y.sqcChk??'',y.sqcOk??'',y.under??'',y.over??'',y.leak??'',y.trucks??'',y.lorries??''])});dl(`HaldiaLPG_Hourly_${d}.csv`,csv(rows))}
function exportMIS(){const t=[...document.querySelectorAll('main table')][0];const rows=[...t.rows].map(r=>[...r.cells].map(c=>c.innerText));dl(`HaldiaLPG_MIS_${M()}.csv`,csv(rows))}
function publishFile(){dl('data.json',JSON.stringify(STORE),'application/json')}
function backup(){dl(`HaldiaLPG_Backup_${todayStr()}.json`,JSON.stringify(STORE),'application/json')}
function restore(inp){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const o=JSON.parse(r.result);if(!confirm('Restore '+Object.keys(o).length+' records? Existing keys will be overwritten.'))return;for(const k in o)set(k,o[k]);render();toast('Restored')}catch(e){alert('Invalid file')}};r.readAsText(f)}
function wipe(){if(prompt('Type DELETE to clear all data in this browser')!=='DELETE')return;STORE={};persist();render()}

VIEWS.settings=()=>{const s=S();const ta=(f,l)=>`<label style="display:block;margin-bottom:12px"><b>${l}</b> <span class="desc">(one per line)</span><textarea rows="6" onchange="saveList('${f}',this.value)">${esc(s[f].join('\n'))}</textarea></label>`;
 return head('Settings & Masters','Customise equipment list, work points, loss tags, consumables, sales areas, cost heads and targets.')+
 `<div class="card"><h3>Targets / Benchmarks</h3><div class="fg">
 ${[['costPerMT','Cost per MT target (Rs)'],['kwhPerMT','Power target (kWh/MT)'],['scValvePct','SC valve consumption target (% of bottling)'],['delrinPct','Delrin cap consumption target (%)'],['fillAcc','Filling accuracy target (%)'],['dailyMT','Daily bottling target (MT)'],['dptInv','DPT inventory norm (cyl)'],['hrInv','HR inventory norm (cyl)'],['lorryCap','Lorry capacity (cyl)']].map(([k,l])=>`<label>${l}<input type="number" step="any" value="${s.t[k]}" onchange="saveT('${k}',this.value)"></label>`).join('')}
 <label>Plant name<input value="${esc(s.plantName)}" onchange="saveSet('plantName',this.value)"></label></div></div>
 <div class="card grid2"><div>${ta('equipment','Equipment')}${ta('manpower','Manpower work points')}${ta('lossTags','Production loss tags')}</div><div>${ta('consumables','Consumables')}${ta('salesAreas','Sales areas')}${ta('revexHeads','Revex cost heads')}</div></div>`};
function saveList(f,v){const s=get('settings',{});s[f]=v.split('\n').map(x=>x.trim()).filter(Boolean);set('settings',s);toast('Saved ✓')}
function saveT(k,v){const s=get('settings',{});s.t=s.t||{};s.t[k]=N(v);set('settings',s);toast('Saved ✓')}
function saveSet(k,v){const s=get('settings',{});s[k]=v;set('settings',s);toast('Saved ✓')}

/* =========================================================
   SAMPLE DATA (for preview only)
   ========================================================= */
function demo(){if(!confirm('Load SAMPLE data for the current month? (Overwrites daily entries for those dates)'))return;
 const s=S(),m=todayStr().slice(0,7),today=todayStr(),R=(a,b)=>Math.round(a+Math.random()*(b-a));
 daysOfMonth(m).filter(d=>d<=today).forEach(d=>{
  const isT=d===today,nowH=new Date().getHours();
  set(dk(d,'start'),{stdA:'06:00',stdB:'14:00',actA:'06:00',introA:'06:'+String(R(2,20)).padStart(2,'0'),actB:'14:00',introB:'14:'+String(R(2,15)).padStart(2,'0'),inchA:'Shed Officer A',inchB:'Shed Officer B'});
  const mp={};s.manpower.forEach(x=>{const q=R(1,x.includes('Shed Labour')?30:x.includes('Loading')?20:4);mp[x]={req:q,A:q-R(0,1),B:q-R(0,1)}});set(dk(d,'manpower'),mp);
  const eq={};s.equipment.forEach(x=>eq[x]={st:Math.random()<.08?'Not Working':Math.random()<.05?'Under Maintenance':'Working',t:'06:45'});set(dk(d,'equip'),eq);
  const h={};HOURS.forEach(x=>{const hh=parseInt(x);if(isT&&hh>nowH)return;const brk=hh===13||hh===14;h[x]={c142:brk?R(300,600):R(1000,1350),c19:R(20,90),c5:R(0,40),c475:R(0,12),sqcChk:48,sqcOk:R(46,48),trucks:R(2,6),lorries:R(2,5)};const y=h[x];const bad=48-y.sqcOk;y.under=Math.floor(bad/2);y.over=bad-y.under;y.leak=0});set(dk(d,'hourly'),h);
  set(dk(d,'loss'),Math.random()<.6?[{shift:'A',from:'09:10',to:'09:'+String(R(20,55)),tag:s.lossTags[R(0,6)],eq:s.equipment[R(0,4)],cyl:R(100,400),rem:'Attended and restored',by:'Shed Officer'}]:[]);
  const c={};s.consumables.forEach(x=>{const v=x==='SC Valves'?R(150,260):x==='Delrin Caps'?R(1500,2200):x==='O-Rings'?R(1500,2000):x==='PVC Seals'?R(16000,19000):x.includes('Paint')?R(8,15):x.includes('Primer')?R(5,9):R(2,20);c[x]={iA:Math.round(v*.55),iB:Math.round(v*.5),issued:Math.round(v*1.05),consumed:v}});set(dk(d,'cons'),c);
  set(dk(d,'salvage'),{valveRecv:R(150,250),valveSalv:R(80,140),valveScrap:R(10,40),capRecv:R(400,700),capSalv:R(250,500),capScrap:R(20,80)});
  set(dk(d,'dpt'),{dpt:R(30,80),hr:R(20,60),ptSent:R(80,150),ptRecv:R(80,160),cold:R(10,40),evac:R(10,30),bodyLeak:R(0,5),bungLeak:R(0,5),corrected:'YES'});
  const inv=[];const nL=R(35,55);for(let i=0;i<nL;i++){const a=Math.random()<.75?s.salesAreas[0]:s.salesAreas[1]||s.salesAreas[0];inv.push({area:a,time:String(R(7,21)).padStart(2,'0')+':'+String(R(0,59)).padStart(2,'0'),lorry:'WB'+R(10,99)+'X'+R(1000,9999),inv:'INV'+R(100000,999999),dist:a+' Dist '+R(1,40),c142:R(300,342),c19:R(0,20)})}set(dk(d,'invoice'),inv);
  const o=R(100000,200000);set(dk(d,'elec'),{open:o,close:o+R(1700,2400),mf:1,md:R(300,450),pf:0.98,dg:R(0,60)});
  set(dk(d,'stock'),{c142:{filled:R(8000,15000),empty:R(20000,30000),def:R(300,800)},c19:{filled:R(500,1200),empty:R(1000,2000),def:R(20,60)},c5:{filled:R(200,500),empty:R(300,800),def:R(5,20)},c475:{filled:R(50,150),empty:R(100,250),def:R(2,10)},dptInv:R(700,1300),hrInv:R(600,950),bulk:R(400,900)});
 });
 prevMonths(m,6).forEach(mm=>{const rv={};s.revexHeads.forEach((h,i)=>{const b=[300000,1100000,8000,20000,500000,1800000,1600000,3000000,150000,5000,950000,50000][i]||50000;rv[h]={bud:b,act:Math.round(b*(0.8+Math.random()*.35))}});set(mk(mm,'revex'),rv);
  if(mm!==m){/* rough prior-month production so 12-month trend is visible */ set(mk(mm,'prodOverride'),{mt:R(6000,7600)})}});
 set(mk(m,'capex'),[{job:'CCTV storage augmentation (180-day retention)',aa:'AA/HLD/01',san:2500000,po:2200000,month:400000,cum:1300000,st:'In Progress'},{job:'Boom barriers with VAMS integration',aa:'AA/HLD/02',san:1800000,po:1650000,month:0,cum:0,st:'Tendering'},{job:'Centralised soap solution system',aa:'AA/HLD/03',san:450000,po:420000,month:0,cum:420000,st:'Completed'}]);
 set(mk(m,'ptpaint'),{norm:110});
 toast('Sample data loaded');render();
}

/* =========================================================
   INIT
   ========================================================= */
$('#gDate').value=todayStr();$('#gMonth').value=todayStr().slice(0,7);
$('#gDate').onchange=()=>{$('#gMonth').value=$('#gDate').value.slice(0,7);render()};$('#gMonth').onchange=render;
window.onhashchange=()=>{const p=location.hash.slice(1);if(p&&p!==PAGE){PAGE=p;render()}};
setInterval(()=>{$('#clock').textContent=new Date().toLocaleString('en-IN',{hour12:false,day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',second:'2-digit'})},1000);
setInterval(()=>{const a=document.activeElement;if(PAGE==='dash'&&!(a&&['INPUT','SELECT','TEXTAREA'].includes(a.tagName)))render()},60000);
window.addEventListener('storage',e=>{if(e.key===LS){STORE=JSON.parse(e.newValue||'{}');if(PAGE==='dash')render()}});
render();loadPublished();
